CREATE TABLE hit (
thedate string,
ad_id string,
pid string,
result string,
hit_time string,
miniute_5 string,
hour string,
records tlong
)
