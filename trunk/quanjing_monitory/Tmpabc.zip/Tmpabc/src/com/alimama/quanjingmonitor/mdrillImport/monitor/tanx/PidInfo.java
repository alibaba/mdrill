package com.alimama.quanjingmonitor.mdrillImport.monitor.tanx;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

public class PidInfo {

	public PidInfo(String pid, String[] mailto, String[] wangwang,
			double overrate,String pidname) {
		this.pid = pid;
		this.mailto = mailto;
		this.wangwang = wangwang;
		this.pidname=pidname;
	}
	public String pid;
	public String pidname;
	public String[] mailto;
	public String[] wangwang;
	public double overrate_pv=0.80;
	public double overrate_click=1.5;
	public double overrate_ctr=0.80;



	public static HashMap<String,PidInfo> getPidInfo(String filePath)
	{
		HashMap<String,PidInfo> pidinfo=new HashMap<String, PidInfo>();
		
		File file = new File(filePath);
		if (file.isFile() && file.exists()) {
			try {
				InputStreamReader read = new InputStreamReader(	new FileInputStream(file), "UTF-8");
				BufferedReader reader = new BufferedReader(read);
				String line;
				try {
					while ((line = reader.readLine()) != null) {
						String[] cols=line.split("\t");
						if(cols.length<3)
						{
							continue;
						}
						
						String pid=cols[0];
						String[] mailto=cols[1].split(",");
						String[] wangwang={"锦觅","子落"};
						double overrate=Double.parseDouble(cols[2]);
						String pidname="无";
						if(cols.length>3)
						{
							pidname=cols[3];
						}
						PidInfo info=new PidInfo(pid, mailto, wangwang, overrate,pidname);
						pidinfo.put(pid, info);
					
					}
					reader.close();
					read.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		return pidinfo;
		}
}
