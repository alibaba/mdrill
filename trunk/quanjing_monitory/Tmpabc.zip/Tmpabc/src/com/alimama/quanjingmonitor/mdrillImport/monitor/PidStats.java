package com.alimama.quanjingmonitor.mdrillImport.monitor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import com.taobao.tddl.tddl_sample.atom.AtomDataSourceDao.ConfigInfo;


public class PidStats {
	HashMap<String,ArrayList<PidStat>> pidStatMap=new HashMap<String,ArrayList<PidStat>>();

	public void add(String pid,PidStat s)
	{
		ArrayList<PidStat> list=this.pidStatMap.get(pid);
		if(list==null)
		{
			list=new ArrayList<PidStat>();
			this.pidStatMap.put(pid, list);
		}
		list.add(s);
	}
	
	public void addList(String pid,ArrayList<PidStat> s)
	{
		ArrayList<PidStat> list=this.pidStatMap.get(pid);
		if(list==null)
		{
			list=new ArrayList<PidStat>();
			this.pidStatMap.put(pid, list);
		}
		
		list.addAll(s);
	}
	
	public String toMailString(HashMap<String,ArrayList<PidStat>> exclude,HashMap<String,PidInfo> pidinfo,HashMap<String,PidInfo> notsend,HashMap<String,ConfigInfo> pidConfigInfo)
	{
		StringBuffer buffer=new StringBuffer();
		for(Entry<String,ArrayList<PidStat>> e:pidStatMap.entrySet())
		{
			String pid=e.getKey();
			if(!exclude.containsKey(pid)&&pidinfo.containsKey(pid)&&!notsend.containsKey(pid))
			{
				buffer.append(PidStat.print(e.getValue(),pidinfo.get(pid),pidConfigInfo.get(pid)));
			}
		}	
		return buffer.toString();
	}
	
	public static HashMap<String,PidStats> read(File file) throws IOException
	{
		HashMap<String,PidStats> mailTonew=new HashMap<String,PidStats>();
		if(!file.exists())
		{
			return mailTonew;
		}
		
		DataInputStream input=new DataInputStream(new FileInputStream(file));
		
		int size=input.readInt();
		for(int i=0;i<size;i++)
		{


			String strkey=input.readUTF();
			PidStats buffer=mailTonew.get(strkey);
			if(buffer==null)
			{
				buffer=new PidStats();
				mailTonew.put(strkey, buffer);
			}
			
			int pidsize=input.readInt();
			for(int j=0;j<pidsize;j++)
			{
				String pid=input.readUTF();
				int listsize=input.readInt();
				ArrayList<PidStat> list=new ArrayList<PidStat>();
				for(int k=0;k<listsize;k++)
				{
					list.add(PidStat.read(input));
				}
				
				buffer.pidStatMap.put(pid,list);
			}			
		}
		
		input.close();
		
		return mailTonew;
	}
	
	public static void write(File file,HashMap<String,PidStats> mailToImprove) throws IOException
	{
		if(file.exists())
		{
			file.delete();
		}
		
		file.createNewFile();

		
		DataOutputStream output=new DataOutputStream(new FileOutputStream(file, true));
		
		output.writeInt(mailToImprove.size());
		for(Entry<String,PidStats> e:mailToImprove.entrySet())
		{
			output.writeUTF(e.getKey());
			output.writeInt(e.getValue().pidStatMap.size());
			for(Entry<String, ArrayList<PidStat>>  ee:e.getValue().pidStatMap.entrySet())
			{
				output.writeUTF(ee.getKey());
				ArrayList<PidStat> v=ee.getValue();
				output.writeInt(v.size());
				for(PidStat s:v)
				{
					PidStat.write(output, s);
				}
			}
		}
		
		output.close();
	}
	
	public static void merger(HashMap<String,PidStats> rtn,HashMap<String,PidStats> ab)
	{
		for(Entry<String,PidStats> e:ab.entrySet())
		{
			PidStats buffer=rtn.get(e.getKey());
			if(buffer==null)
			{
				buffer=new PidStats();
				rtn.put(e.getKey(), buffer);
			}
			
			for(Entry<String, ArrayList<PidStat>> ee:e.getValue().pidStatMap.entrySet())
			{
				buffer.addList(ee.getKey(), ee.getValue());
			}
		}
	}

}
