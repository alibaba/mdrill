package com.alimama.quanjingmonitor.mdrillImport.monitor.tanx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import com.taobao.tddl.tddl_sample.atom.AtomDataSourceDao.ConfigInfo;


public class monitorUtils {

	 public static SimpleDateFormat formatDay = new SimpleDateFormat("yyyyMMdd");

	 public static SimpleDateFormat formatMin = new SimpleDateFormat("HHmm");
	 
	 public static SimpleDateFormat formatDayHHMM = new SimpleDateFormat("yyyyMMdd_HHmm");

		public static long delaymin=3600;
	
	public static String  getMD5(byte[] bytes) { 
        char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' }; 
        char str[] = new char[16 * 2]; 
        try { 
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5"); 
            md.update(bytes); 
            byte tmp[] = md.digest(); 
            int k = 0; 
            for (int i = 0; i < 16; i++) { 
                byte byte0 = tmp[i]; 
                str[k++] = hexDigits[byte0 >>> 4 & 0xf]; 
                str[k++] = hexDigits[byte0 & 0xf]; 
            } 
        } catch (Exception e) { 
        } 
        return new String(str); 
    } ;
    

	public static void Request(StringBuffer urlFormat ) throws IOException
	{
        URL u = new URL("http://mon.alibaba-inc.com/noticenter/send.do");
        HttpURLConnection con = (HttpURLConnection) u.openConnection();
        con.setRequestMethod("POST");
        con.setDoOutput(true);
        con.setDoInput(true);
        con.setUseCaches(false);
        con.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
        OutputStreamWriter osw = new OutputStreamWriter(con.getOutputStream(),"UTF-8");
        osw.write(urlFormat.toString());
        osw.flush();
        osw.close();
        
        InputStreamReader urlStream = new InputStreamReader(con.getInputStream(), "utf-8");
        BufferedReader in = new BufferedReader(urlStream);
        int bufferlen = 1;
        char[] buffer = new char[bufferlen];
        int readBytes = 0;

        while (true) {
                readBytes = in.read(buffer, 0, bufferlen);
                if (readBytes < 0) {
                        break;
                }
          }
        in.close();
        urlStream.close();
        con.disconnect();
	}
    
	public static void sendMailTo(HashMap<String,PidStats> mailTo,HashMap<String,PidStats> old,String day_ts,HashMap<String,PidStats> exclude,String title,HashMap<String,PidInfo> pidinfo,HashMap<String,PidInfo> notsend,HashMap<String,ConfigInfo> pidConfigInfo)
	{
		for(Entry<String,PidStats> e:mailTo.entrySet())
		{
			String mailinfo=e.getKey();
			HashMap<String,ArrayList<PidStat>> info=exclude.containsKey(mailinfo)?exclude.get(mailinfo).pidStatMap:new HashMap<String,ArrayList<PidStat>>();
			
			HashMap<String,ArrayList<PidStat>> oldinfo=old.containsKey(mailinfo)?old.get(mailinfo).pidStatMap:new HashMap<String,ArrayList<PidStat>>();

			String cnet=e.getValue().toMailString(oldinfo,info,pidinfo,notsend,pidConfigInfo);
			if(cnet.isEmpty())
			{
				continue;
			}
			try {
				StringBuffer contentw=new StringBuffer();

				contentw.append(" 全景监控访问地址：http://42.156.210.133:9999/quanjing/tanxpv.jsp <br>");
				contentw.append("<table width='100%' border='1' cellspacing='0' cellpadding='0'>");
				contentw.append("<tr><td>pid</td><td>开始</td><td>结束</td><td>名称</td><td>报警阈值</td><td>日期</td><td>点击</td><td>PV</td><td>点击率%</td></tr>");
				contentw.append(cnet);
				contentw.append("</table>");
				StringBuffer urlFormat = new StringBuffer();;
				urlFormat.append("receiver="+URLEncoder.encode(mailinfo ,"utf8"));

				urlFormat.append("&subtitle="+URLEncoder.encode("【全景监控】您的TANX有异常的pid需要处理["+title+":"+day_ts+"]" ,"utf8"));
			
				urlFormat.append("&message="+URLEncoder.encode(contentw.toString() ,"utf8"));
				urlFormat.append("&method="+URLEncoder.encode("mail" ,"utf8"));
				urlFormat.append("&username="+URLEncoder.encode("yannian.mu" ,"utf8"));
				urlFormat.append("&password="+monitorUtils.getMD5((new String("yannian.mu@1106"+e.getKey())).getBytes("utf8")));
				urlFormat.append("&charset=utf8");
				
				
				
				Request(urlFormat);
				
				
			} catch (Exception e2) {
			}
		}
	}
}
