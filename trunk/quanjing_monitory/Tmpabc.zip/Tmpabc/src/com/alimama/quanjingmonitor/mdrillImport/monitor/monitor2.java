package com.alimama.quanjingmonitor.mdrillImport.monitor;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;

import com.alimama.mdrill.utils.TryLockFile;
import com.taobao.tddl.tddl_sample.atom.AtomDataSourceDao;
import com.taobao.tddl.tddl_sample.atom.AtomDataSourceDao.ConfigInfo;

public class monitor2 {
	public static void main(String[] args) throws SQLException, ClassNotFoundException, IOException {

		String path=args[1];
		String lockname=args[2];
		String issend=args[3];
		
		String stormhome = System.getProperty("storm.home");
		if (stormhome == null) {
			stormhome=".";
		}
		
		String lockPathBase=stormhome+"/lock";
		File file = new File(lockPathBase);
		file.mkdirs();
		TryLockFile flock=new TryLockFile(lockPathBase+"/"+lockname);
		flock.trylock();
		long ts=System.currentTimeMillis();
		execute(ts,path,issend);
		
		flock.unlock();
	}
	

	public static void mointorBatch(HashMap<String,PidStats> mailTo,HashMap<String,PidStats> mailToImprove,long ts,HashMap<String,PidInfo> pidinfo,ArrayList<String> pidlist) throws SQLException, ClassNotFoundException
	{
		HashMap<String,PidStat> requestData=PidStat.request(ts, pidinfo, pidlist);
		for(Entry<String,PidStat> e:requestData.entrySet())
		{
			String pid=e.getKey();
			PidInfo info=pidinfo.get(pid);
			PidStat stat=e.getValue();
			stat.makectr();

			if(info!=null)
			{
				System.out.println(stat.printlog(info));

				if(stat.hasValueOverMinPrice()&&stat.isover(info,false))
				{
					if(stat.isover(info,true))
					{
						for(String mail:info.mailto)
						{
							PidStats buffer=mailTo.get(mail);
							if(buffer==null)
							{
								buffer=new PidStats();
								mailTo.put(mail, buffer);
							}
							buffer.add(pid,stat);
						}
					}else{
						for(String mail:info.mailto)
						{
							PidStats buffer=mailToImprove.get(mail);
							if(buffer==null)
							{
								buffer=new PidStats();
								mailToImprove.put(mail, buffer);
							}
							buffer.add(pid,stat);
						}
						
					}
				}
			}
		}

	}
	
	public static void execute(long ts,String filePath,String issend) throws SQLException, ClassNotFoundException, IOException
	{
		long belongDay_ts=ts-1000l*3600*15;

		String belog_day=monitorUtils.formatDay.format(new Date(belongDay_ts));

		File file_improve = new File(new File(filePath).getParentFile(),"improve_"+belog_day+"_"+(new File(filePath).getName())+".log");
		HashMap<String,PidStats> oldmailTo_improve=PidStats.read(file_improve);
		
		File file_reduce = new File(new File(filePath).getParentFile(),"reduce_"+belog_day+"_"+(new File(filePath).getName())+".log");
		HashMap<String,PidStats> oldmailTo_reduce=PidStats.read(file_reduce);	
		HashMap<String,PidInfo> pidinfo=PidInfo.getPidInfo(filePath);
		HashMap<String,PidInfo> notsend=PidInfo.getPidInfo(filePath+".notin");
		HashMap<String,ConfigInfo> pidConfigInfo=AtomDataSourceDao.query();

		if(issend.indexOf("execute")>=0||issend.indexOf("veryimport")>=0)
		{
			HashMap<String,PidStats> mailToImprove=new HashMap<String,PidStats>();
			HashMap<String,PidStats> mailToReduce=new HashMap<String,PidStats>();
			ArrayList<String> pidlist=new ArrayList<String>();
			
			for(Entry<String,PidInfo> e:pidinfo.entrySet())
			{
				pidlist.add(e.getKey());
				if(pidlist.size()>49)
				{
					mointorBatch(mailToReduce,mailToImprove,ts,pidinfo, pidlist);
					pidlist.clear();
				}
			}
			
			if(pidlist.size()>0)
			{
				mointorBatch(mailToReduce,mailToImprove,ts,pidinfo, pidlist);
				pidlist.clear();
			}
		
			if(issend.indexOf("veryimport")>=0)
			{
				monitorUtils.sendMailTo(mailToReduce, monitorUtils.formatDay.format(new Date(ts)),oldmailTo_reduce,"关键pid降低",pidinfo,notsend,pidConfigInfo);
				monitorUtils.sendMailTo(mailToImprove, monitorUtils.formatDay.format(new Date(ts)),oldmailTo_improve,"关键pid增加",pidinfo,notsend,pidConfigInfo);
			}
			PidStats.merger(mailToReduce,oldmailTo_reduce);
			PidStats.merger(mailToImprove,oldmailTo_improve);
			
			PidStats.write(file_reduce, mailToReduce);
			PidStats.write(file_improve, mailToImprove);
			
			return ;
		
		}

		if(issend.indexOf("send")>=0)
		{
			monitorUtils.sendMailTo(oldmailTo_reduce, monitorUtils.formatDay.format(new Date(ts)),new HashMap<String, PidStats>(),"降低",pidinfo,notsend,pidConfigInfo);
			monitorUtils.sendMailTo(oldmailTo_improve, monitorUtils.formatDay.format(new Date(ts)),new HashMap<String, PidStats>(),"增加",pidinfo,notsend,pidConfigInfo);
		}


	}
	
}
