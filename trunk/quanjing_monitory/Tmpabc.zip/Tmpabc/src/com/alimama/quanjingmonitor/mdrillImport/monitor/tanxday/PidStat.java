package com.alimama.quanjingmonitor.mdrillImport.monitor.tanxday;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import com.alimama.mdrill.jdbc.MdrillQueryResultSet;
import com.taobao.tddl.tddl_sample.atom.AtomDataSourceDao.ConfigInfo;

public class PidStat {
	public static void main(String[] args) {
		System.out.println("2300".compareTo("2259"));
	}
	private String start;
	private String end;
	private String[] dayList;
	private double[] p4pclick;
	private double[] p4ppv;
	private double[] p4pctr;

	
	public static String print(ArrayList<PidStat> listraw, PidInfo info,ConfigInfo pidconfig)
	{
		if(pidconfig!=null&&pidconfig.isIsnotsend())
		{
			return "";
		}
		ArrayList<PidStat> list=new ArrayList<PidStat>();
		for( PidStat p:listraw)
		{
			list.add(p);
		}
		
		StringBuffer buff =new StringBuffer();
		int index=0;
		int maxsize=3;

		int size=list.size();
		int rowspan=Math.max(Math.min(size, maxsize), 0);
		for(int i=0;i<list.size();i++)
		{
			if(index>=maxsize)
			{
				break;
			}
			buff.append(list.get(i).print(info,index,rowspan,size,pidconfig));
			index++;

		}
		
		return buff.toString();
	}
	public String arrayToString(String[] d,String joinchar)
	{
		StringBuffer buff=new StringBuffer();
		String join ="";
		for(Object s:d)
		{
			buff.append(join).append(s);
			join=joinchar;
		}
		
		return buff.toString();
	}
	
	public String arrayToString(double[] d,String joinchar,String f)
	{
		DecimalFormat format=new DecimalFormat(f);
		StringBuffer buff=new StringBuffer();
		String join ="";
		for(double s:d)
		{
			buff.append(join).append(format.format(s));
			join=joinchar;
		}
		
		return buff.toString();
	}
	
	public String printIsOver(double overrate,double[] d,String joinchar,String format)
	{
		boolean isover=this.isover(overrate, d,false);
		if(isover)
		{
			return "<font color='red'>"+arrayToString(d,joinchar,format)+"</font>";
		}
		return arrayToString(d,joinchar,format);
	}
	
	public String print(PidInfo info,int index,int span,int size,ConfigInfo cinfo) {
		String rowspan="<td rowspan='"+span+"'>" + info.pid+"(共"+size+"条)"+ ""+(cinfo==null?"":"<br>"+cinfo.getMessage())+ "</td>";
		if(index>0)
		{
			rowspan="";
		}
		
		return "<tr>"+rowspan+"<td>"+start+ "</td><td>" + end + "</td><td>" + info.pidname+ "</td><td>pv:" + info.overrate_pv+",click:"+ info.overrate_click+",ctr"+ info.overrate_ctr
				+ "</td><td>" + arrayToString(dayList,"<br>") + "</td>" +
						"<td>"+printIsOver(info.overrate_click,this.p4pclick,"<br>","0") + "</td>" +
						"<td>"+printIsOver(info.overrate_pv,this.p4ppv,"<br>","0") + "</td><td>"+printIsOver(info.overrate_ctr,this.p4pctr,"<br>","0.00") + "</td></tr>";
	}
	
	
	public String printlog(PidInfo info) {
		return start + "\t" + end + "\t" + info.pid + "\t" + info.pidname+ "\t+pv:" + info.overrate_pv+",click:"+ info.overrate_click+",ctr"+ info.overrate_ctr
				+ "\t" + arrayToString(dayList,",") + "\t"
				+ arrayToString(p4pclick,",","0")+"\t"+isover(info.overrate_click,this.p4pclick,false) 
				+ "\t" + arrayToString(p4ppv,",","0")+"\t"+isover(info.overrate_pv,this.p4ppv,false)+ "\t" + arrayToString(p4pctr,",","0.00")+"\t"+isover(info.overrate_ctr,this.p4pctr,false) +"\t"+ "";
	}

	
	public static PidStat read(DataInputStream input) throws IOException
	{
		PidStat rtn=new PidStat();
		rtn.start=input.readUTF();
		rtn.end=input.readUTF();
		
		int size=input.readInt();
		rtn.dayList=readString(input, size);
		rtn.p4pclick=readDouble(input, size);
		rtn.p4ppv=readDouble(input, size);
		rtn.p4pctr=readDouble(input, size);
		return rtn;
	}
	
	public static void write(DataOutputStream output,PidStat s) throws IOException
	{
		output.writeUTF(s.start);
		output.writeUTF(s.end);
		int size=s.dayList.length;
		output.writeInt(size);
		writeString(output, size, s.dayList);
		writeDouble(output, size, s.p4pclick);
		writeDouble(output, size, s.p4ppv);
		writeDouble(output, size, s.p4pctr);


	}
	
	public static  void writeString(DataOutputStream output, int size,String[] s) throws IOException
	{
		for(int i=0;i<size;i++)
		{
			output.writeUTF(s[i]);
		}
	}
	
	public static  void writeDouble(DataOutputStream output, int size,double[] s) throws IOException
	{
		for(int i=0;i<size;i++)
		{
			output.writeDouble(s[i]);
		}
	}
	
	public static double[] readDouble(DataInputStream input,int size) throws IOException
	{
		double[] rtn=new double[size];
		for(int i=0;i<size;i++)
		{
			rtn[i]=input.readDouble();
		}
		return rtn;
	}
	
	public static String[] readString(DataInputStream input,int size) throws IOException
	{
		String[] rtn=new String[size];
		for(int i=0;i<size;i++)
		{
			rtn[i]=input.readUTF();
		}
		return rtn;
	}
	
	public void makectr()
	{
		this.p4pctr=new double[this.dayList.length];
		
		for(int i=0;i<this.dayList.length;i++)
		{
			this.p4pctr[i]=0;
			if(this.p4ppv[i]>0&&this.p4ppv[i]>this.p4pclick[i])
			{
				this.p4pctr[i]=this.p4pclick[i]*100/this.p4ppv[i];
			}
		}
	}
	

	

	public boolean isover(PidInfo info,boolean onlyreduce)
	{
	
		if(isover(info.overrate_click,this.p4pclick,onlyreduce)&&!isDiffLessThen(500d,this.p4pclick))
		{
			return true;
		}
		
		if(isover(info.overrate_ctr,this.p4pctr,onlyreduce)&&!isDiffLessThen(500d,this.p4pclick)&&!isDiffLessThen( 0.04,this.p4pctr))
		{
			return true;
		}
		
		if(isover(info.overrate_pv,this.p4ppv,onlyreduce)&&!isDiffLessThen(10000d,this.p4ppv))
		{
			return true;
		}
		
		return false;
	}
	
	
	
	public boolean isAllLessThen(double minvalue,double[] d)
	{
		for(int i=0;i<d.length;i++)
		{
			if(d[i]<minvalue)
			{
				continue;
			}
			
			return false;
		}
		
		return true;
	}
	
	
	public boolean isDiffLessThen(double minvalue,double[] d)
	{
		double base=d[0];
		for(int i=1;i<d.length;i++)
		{
			double diff=Math.abs(base-d[i]);
			if(diff<minvalue)
			{
				continue;
			}
			
			return false;
		}
		return true;
	}
	

	
	private boolean isover(double overrate,double[] d,boolean onlyreduce)
	{
		double base=d[0];
		boolean isset=false;
		for(int i=1;i<d.length;i++)
		{
			if(d[i]<=0.02)
			{
				continue;
			}
			
			
			isset=true;
			double diff=Math.abs(base-d[i])/(0.0001+d[i]);
			double diff2=Math.abs(base-d[i])/(0.0001+base);

			if(diff<overrate&&diff2<overrate)
			{
				return false;
			}
			
			if(onlyreduce&&base>d[i])
			{
				return false;
			}
		}
		
		return isset;
	}
	
	
	public static HashMap<String,PidStat> request(long ts,HashMap<String,PidInfo> pidinfo,ArrayList<String> pidlist) throws SQLException, ClassNotFoundException
	{
		Class.forName("com.alimama.mdrill.jdbc.MdrillDriver");
		
		HashMap<String,PidStat> rtn=new HashMap<String, PidStat>();
		
		String[] dayList={
				monitorUtils.formatDay.format(new Date(ts-1000l*monitorUtils.delaymin))
				,monitorUtils.formatDay.format(new Date(ts-1000l*monitorUtils.delaymin-1000l*3600*24*1))
				,monitorUtils.formatDay.format(new Date(ts-1000l*monitorUtils.delaymin-1000l*3600*24*2))
				,monitorUtils.formatDay.format(new Date(ts-1000l*monitorUtils.delaymin-1000l*3600*24*3))
				,monitorUtils.formatDay.format(new Date(ts-1000l*monitorUtils.delaymin-1000l*3600*24*7))
				};
		
		HashMap<String,Integer> dayIndex=new HashMap<String, Integer>();
		for(int i=0;i<dayList.length;i++)
		{
			dayIndex.put(dayList[i], i);
		}
		
		String start="0000";//monitorUtils.formatMin.format(new Date(ts-1000l*monitorUtils.delaymin-1000l*3600));
		String end="2359";monitorUtils.formatMin.format(new Date(ts-1000l*monitorUtils.delaymin));
		
		String minfilter= " miniute_5>='0000' and miniute_5<='2359' ";
//		if(start.compareTo(end)>=0)
//		{
//			minfilter="  ((miniute_5>='"+start+"' and miniute_5<='2359')  or (miniute_5<='"+end+"' and miniute_5>='0000') )";
//		}

		StringBuffer pidliststr=new StringBuffer();
		String join="";
		for(String pid:pidlist)
		{
			pidliststr.append(join).append("'"+pid+"'");
			join=",";
		}
		
		
		{

			String sql = "select " + " thedate,pid,sum(records) as records "
					+ " from tanx_pv where thedate in ('" + dayList[0] + "','"
					+ dayList[1] + "','" + dayList[2] + "','" + dayList[3]
					+ "','" + dayList[4] + "') " + " and pid in (" + pidliststr
					+ ") and " + minfilter
					+ " group by thedate,pid limit 0,8000 ";

			Connection con = DriverManager.getConnection(
					"jdbc:mdrill://adhoc7.kgb.cm6:9999", "", "");

			Statement stmt = con.createStatement();

			MdrillQueryResultSet res = null;

			res = (MdrillQueryResultSet) stmt.executeQuery(sql);

			while (res.next()) {
				String thedate = res.getString("thedate");
				String pid = res.getString("pid");
				int index = dayIndex.get(thedate);

				PidStat stat = rtn.get(pid);
				if (stat == null) {
					stat = new PidStat();
					stat.start = start;
					stat.end = end;
					stat.dayList = dayList;
					stat.p4pclick = new double[dayList.length];
					stat.p4ppv = new double[dayList.length];
					rtn.put(pid, stat);
				}

				stat.p4ppv[index] = Double
						.parseDouble(res.getString("records"));
			}
			con.close();

		}
		
		{

			String sql = "select " + " thedate,pid,sum(records) as records "
					+ " from tanx_click where thedate in ('" + dayList[0]
					+ "','" + dayList[1] + "','" + dayList[2] + "','"
					+ dayList[3] + "','" + dayList[4] + "') " + " and pid in ("
					+ pidliststr + ") and " + minfilter
					+ " group by thedate,pid limit 0,8000 ";

			Connection con = DriverManager.getConnection(
					"jdbc:mdrill://adhoc7.kgb.cm6:9999", "", "");

			Statement stmt = con.createStatement();

			MdrillQueryResultSet res = null;

			res = (MdrillQueryResultSet) stmt.executeQuery(sql);

			while (res.next()) {
				String thedate = res.getString("thedate");
				String pid = res.getString("pid");
				int index = dayIndex.get(thedate);

				PidStat stat = rtn.get(pid);
				if (stat == null) {
					stat = new PidStat();
					stat.start = start;
					stat.end = end;
					stat.dayList = dayList;
					stat.p4pclick = new double[dayList.length];
					stat.p4ppv = new double[dayList.length];
					rtn.put(pid, stat);
				}

				stat.p4pclick[index] = Double.parseDouble(res
						.getString("records"));
			}
			con.close();

		}
			
			return rtn;
	}
	

}
