package com.taobao.tddl.tddl_sample.atom;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;


/**
开发环境：tddl.prm.mysql.appName=APP_PRM
tddl.prm.mysql.groupkey=PRM_GROUP 
线上环境：tddl.prm.mysql.appName=APP_PRM
tddl.prm.mysql.groupkey=PRM_GROUP 
测试环境：ddl.prm.mysql.appName=PRM_TST
tddl.prm.mysql.groupkey=PRM_TST_GROUP
 * @author yannian.mu
 *
 */
public class AtomDataSourceDao {
	public static void main(String[] args) {
		System.out.println("111");
        AtomDataSourceDao.query();
        System.exit(0);
	}
	
	/**
{id=32, adzoneid=14478186, siteid=4292002, memberid=26632275, gcid=5, status=1, creator=10000698, modifier=15010438267, createtime=2014-02-20 10:32:14.0, updatetime=2014-05-26 10:38:20.0, adzonename1=PPS-app-H5电商墙-IOS, mediatype1=视频, bdname1=祯姬, cooperatetype1=线下分成, producttype1=H5电商墙, equipmenttype1=iPhone, commission=, amount=, adzonesize=100×100, flowtype=vip视频, productgroup=app, firstproducttype=小淘器, putdate=null, mediumname=PPS, isjs=null, puttype=null, pid=null, lwform=null, daypromiseclick=null

, warnDate=1230, warnProgress=处理完成, warnReason=媒体下线广告位, creatorName=锦觅, warnCommont=广告位下线, flowChangeType=null, flowChangeCommont=null, wirelessMedium=PPS}
{id=41, adzoneid=10961952, siteid=3403476, memberid=33146468, gcid=5, status=1, creator=10000698, modifier=15010438267, createtime=2014-02-20 11:29:48.0, updatetime=2014-05-26 15:57:09.0, adzonename1=oppo浏览器-oppo浏览器, mediatype1=入口, bdname1=佩璐, cooperatetype1=线上分成, producttype1=H5电商墙, equipmenttype1=空白, commission=, amount=, adzonesize=, flowtype=vip大媒体, productgroup=入口, firstproducttype=入口图文, putdate=null, mediumname=oppo, isjs=null, puttype=null, pid=null, lwform=null, daypromiseclick=null, warnDate=1030, warnProgress=未处理, warnReason=媒体下线广告位, creatorName=锦觅, warnCommont=, flowChangeType=null, flowChangeCommont=null, wirelessMedium=OPPO}
{id=495, adzoneid=10961952, siteid=3403476, memberid=33146468, gcid=5, status=1, creator=15010438267, modifier=15010438267, createtime=2014-05-29 10:34:19.0, updatetime=2014-05-29 10:34:19.0, adzonename1=null, mediatype1=null, bdname1=null, cooperatetype1=null, producttype1=null, equipmenttype1=null, commission=null, amount=null, adzonesize=null, flowtype=null, productgroup=null, firstproducttype=null, putdate=null, mediumname=null, isjs=null, puttype=null, pid=null, lwform=null, daypromiseclick=null, warnDate=0900, warnProgress=处理完成, warnReason=媒体下线广告位, creatorName=锦觅, warnCommont=, flowChangeType=null, flowChangeCommont=null, wirelessMedium=OPPO}
	 */

	public static class ConfigInfo
	{
		String pid;
	
		String updatetime;
		String warnReason;
		String warnProgress;
		String warnDate;
		String creatorName;
		String warnCommont;
		boolean isnotsend=false;
		
		public boolean isIsnotsend() {
			return isnotsend;
		}

		@Override
		public String toString() {
			return "ConfigInfo [pid=" + pid + ", warnReason=" + warnReason
					+ ", warnProgress=" + warnProgress + ", warnDate="
					+ warnDate + ", creatorName=" + creatorName
					+ ", warnCommont=" + warnCommont + ", isnotsend="
					+ isnotsend + "]";
		}
		
		public String getMessage()
		{
			StringBuffer buff=new StringBuffer();
			buff.append(warnReason).append(",");
			buff.append(warnProgress).append("<br>");
			buff.append(creatorName).append(",");
			buff.append(warnDate).append(",").append(updatetime).append("<br>");
			buff.append(warnCommont);
			
			return buff.toString();
		}
	}
	
	public static HashMap<String,ConfigInfo> query(){
		com.taobao.tddl.jdbc.group.TGroupDataSource source=new com.taobao.tddl.jdbc.group.TGroupDataSource();
		source.setAppName("APP_PRM");
		source.setDbGroupKey("PRM_GROUP");
		source.init();
		JdbcTemplate tddlJT=new org.springframework.jdbc.core.JdbcTemplate(source);


		
	    String sql="select * from pid_info_5 where warnDate is not null order by updatetime desc limit 0,3000";
		List re=tddlJT.queryForList(sql);
	    System.out.println(re.size());
	    
	    HashMap<String,ConfigInfo> rtn=new HashMap<String, ConfigInfo>();
	    for(int i=0;i<re.size();i++)
	    {
	    	Map item=(Map) re.get(i);
	    	String pid="mm_"+String.valueOf(item.get("memberid"))+"_"+String.valueOf(item.get("siteid"))+"_"+String.valueOf(item.get("adzoneid"))+"";
	    	ConfigInfo info=new ConfigInfo();
	    	info.pid=pid;
	    	info.warnReason=String.valueOf(item.get("warnReason"));
	    	info.isnotsend=info.warnReason.indexOf("媒体下线广告位")>=0;
	    	
	    	info.warnProgress=String.valueOf(item.get("warnProgress"));
	    	info.warnDate=String.valueOf(item.get("warnDate"));
	    	info.creatorName=String.valueOf(item.get("creatorName"));
	    	info.warnCommont=String.valueOf(item.get("warnCommont"));
	    	info.updatetime=String.valueOf(item.get("updatetime"));

	    	if(!rtn.containsKey(pid))
	    	{
	    		rtn.put(pid, info);
	    	}
	
	    }
	    
	    
	    System.out.println(rtn.toString());
	    return rtn;
	}

}
