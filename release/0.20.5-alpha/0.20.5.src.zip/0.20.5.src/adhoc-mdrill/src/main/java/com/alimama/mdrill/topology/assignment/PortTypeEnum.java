package com.alimama.mdrill.topology.assignment;

public enum PortTypeEnum {
	mergerserver,shard,realtime

}
