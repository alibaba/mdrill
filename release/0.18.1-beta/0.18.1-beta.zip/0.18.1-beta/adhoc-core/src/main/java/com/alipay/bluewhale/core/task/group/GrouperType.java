package com.alipay.bluewhale.core.task.group;

/**
 * һ��tuple���鷽ʽ
 * @author yannian
 *
 */
public enum GrouperType {
    global,fields,all,shuffle,none,custom_obj,custom_serialized,direct
}
