package com.alipay.bluewhale.core.task.error;

/**
 * task�ϱ�����Ľӿ�
 * @author yannian
 *
 */
public interface ITaskReportErr {
	 public void report(Throwable error);
}
