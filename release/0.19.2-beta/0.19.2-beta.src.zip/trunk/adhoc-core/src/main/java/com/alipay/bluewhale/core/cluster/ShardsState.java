package com.alipay.bluewhale.core.cluster;

public enum ShardsState {
UINIT,INIT,INITFAIL,SOLRDIE,SOLRSTOP,STARTSOLR,SERVICE,FAIL
}
