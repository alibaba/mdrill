package com.alipay.bluewhale.core.daemon;
/**
 * ����supervisor��worker��״̬
 * @author chenjun
 *
 */
public enum State {
	valid, disallowed, notStarted, timedOut;
}
