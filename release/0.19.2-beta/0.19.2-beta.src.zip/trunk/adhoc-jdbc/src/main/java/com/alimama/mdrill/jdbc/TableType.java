package com.alimama.mdrill.jdbc;

public enum TableType {
	MANAGED_TABLE, EXTERNAL_TABLE, VIRTUAL_VIEW, INDEX_TABLE
}
