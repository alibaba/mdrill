package com.alimama.mdrill.solr.realtime;

public interface IMessage {

    public void setData(final byte[] data) ;
    public byte[] getData() ;


}
