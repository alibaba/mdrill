package com.alipay.bluewhale.core.messaging;

public interface IZMQContext {
	public org.zeromq.ZMQ.Context zmq_context();
}
