package com.alipay.bluewhale.core.cluster;

public interface DaemonCommon {
	public boolean waiting();
}
