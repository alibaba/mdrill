package com.alimama.mdrill.ui.service.utils;

public enum OperateType {
 eq,neq,lg,gt,lgeq,gteq,in,notin,range,other
}
