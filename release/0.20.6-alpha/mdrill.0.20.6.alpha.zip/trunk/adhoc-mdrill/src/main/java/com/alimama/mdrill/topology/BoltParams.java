package com.alimama.mdrill.topology;

public class BoltParams implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
    public  int replication;
    public  int replicationindex;
    public String compname="";
    public String binlog="local";
}
