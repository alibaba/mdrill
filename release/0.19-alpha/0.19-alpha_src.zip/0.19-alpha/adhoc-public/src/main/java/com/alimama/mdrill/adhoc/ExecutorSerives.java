package com.alimama.mdrill.adhoc;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorSerives {
    public static final ExecutorService       EXECUTE  = Executors.newFixedThreadPool(5);

}
