package com.alipay.bluewhale.core.cluster;

import com.alipay.bluewhale.core.callback.BaseCallback;

public class ClusterStateCallback extends BaseCallback {

}
