package com.alipay.bluewhale.core.task;

/**
 * TkHbCacheTime is describle taskheartcache(Map<stormid, Map<taskid, Map<tkHbCacheTime, time>>>) 
 */

public enum TkHbCacheTime {
	nimbusTime, taskReportedTime;
}
